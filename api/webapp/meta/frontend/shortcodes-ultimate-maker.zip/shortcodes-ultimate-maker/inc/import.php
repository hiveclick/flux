<?php
function sumk_import_demo() {
	echo "importing sumk_demo";
	$option = 'sumk_demo_imported';
	if ( get_option( $option ) || !function_exists('shortcodes_ultimate') ) return;
	global $sumk;
	$data = array( array(
			'post_title' => __( 'Demo shortcode #1: HTML code example', $sumk->textdomain ),
			'post_type' => 'shortcodesultimate',
			'post_status' => 'publish',
			'post_date' => date( 'Y-m-d H:i:03' ),
			'meta' => array(
				'name' => __( 'Demo shortcode #1: HTML code example', $sumk->textdomain ),
				'slug' => 'demo_shortcode_1',
				'desc' => __( 'This shortcode written with simple HTML and allows you to change the color of selected text', $sumk->textdomain ),
				'content' => __( 'Default content', $sumk->textdomain ),
				'icon' => $sumk->assets( 'images', 'demo-1.png' ),
				'attr' => serialize( array( array(
							'name' => __( 'Text color', $sumk->textdomain ),
							'desc' => __( 'Color of selected text', $sumk->textdomain ),
							'slug' => 'color',
							'default' => '#ff3333',
							'type' => 'color' ) ) ),
				'code_type' => 'html',
				'code' => esc_html( "<span style=\"color: {{color}}\">{{content}}</span>" )
			) ),
		array(
			'post_title' => __( 'Demo shortcode #2: PHP return code example', $sumk->textdomain ),
			'post_type' => 'shortcodesultimate',
			'post_status' => 'publish',
			'post_date' => date( 'Y-m-d H:i:02' ),
			'meta' => array(
				'name' => __( 'Demo shortcode #2: PHP return code example', $sumk->textdomain ),
				'slug' => 'demo_shortcode_2',
				'desc' => __( 'This shortcode does the same thing as a shortcode #1 but written in PHP and uses PHP return mode',
					$sumk->textdomain ),
				'content' => __( 'Default content', $sumk->textdomain ),
				'icon' => $sumk->assets( 'images', 'demo-2.png' ),
				'attr' => serialize( array( array(
							'name' => __( 'Text color', $sumk->textdomain ),
							'desc' => __( 'Color of selected text', $sumk->textdomain ),
							'slug' => 'color',
							'default' => '#ff3333',
							'type' => 'color' ) ) ),
				'code_type' => 'php_return',
				'code' => esc_html( 'return \'<span style="color: \' . $color . \'">\' . $content . \'</span>\';' )
			) ),
		array(
			'post_title' => __( 'Demo shortcode #3: PHP echo code example', $sumk->textdomain ),
			'post_type' => 'shortcodesultimate',
			'post_status' => 'publish',
			'post_date' => date( 'Y-m-d H:i:01' ),
			'meta' => array(
				'name' => __( 'Demo shortcode #3: PHP echo code example', $sumk->textdomain ),
				'slug' => 'demo_shortcode_3',
				'desc' => __( 'This shortcode is more complex than shortcodes #1 and #2. This example will show you how to use PHP echo mode, as well as how to use several different types of attributes',
					$sumk->textdomain ),
				'content' => __( 'Default content', $sumk->textdomain ),
				'icon' => $sumk->assets( 'images', 'demo-3.png' ),
				'attr' => serialize( array( array(
							'name' => __( 'Style', $sumk->textdomain ),
							'desc' => __( 'Select box style', $sumk->textdomain ),
							'slug' => 'style',
							'default' => 'success',
							'type' => 'select',
							'options' => sprintf( "info|%s\nerror|%s\nsuccess|%s", __( 'Info', $sumk->textdomain ), __( 'Error', $sumk->textdomain ), __( 'Success', $sumk->textdomain ) )
						), array(
							'name' => __( 'Size', $sumk->textdomain ),
							'desc' => __( 'Choose box size', $sumk->textdomain ),
							'slug' => 'size',
							'default' => 3,
							'type' => 'number',
							'min' => 1,
							'max' => 10,
							'step' => 1
						)
					) ),
				'code_type' => 'php_echo',
				'code' => esc_html( '$styles = array(\'info\', \'error\', \'success\');' . "\n" . '$colors = array(\'#09c\', \'#f03\', \'#6c3\');' . "\n" . '$color = str_replace($styles, $colors, $style);' . "\n" . '$size = round($size * 1.4 + 9);' . "\n" . 'echo \'<div style="background: \' . su_hex_shift($color, \'lighter\', 40) . \';color:\' . su_hex_shift($color, \'darker\', 40) . \';font-size:\' . $size . \'px;margin:0 0 1.5em;padding:\' . $size . \'px">\' . $content . \'</div>\';' )
			) ),
		array(
			'post_title' => __( 'Flux Question', $sumk->textdomain ),
			'post_type' => 'shortcodesultimate',
			'post_status' => 'publish',
			'post_date' => date( 'Y-m-d H:i:03' ),
			'meta' => array(
				'name' => __( 'Flux Question', $sumk->textdomain ),
				'slug' => 'flux_question',
				'desc' => __( 'Adds a question to the site that will be stored into a lead in flux', $sumk->textdomain ),
				'content' => __( '<div class="text-center"><div class="col-md-6"><input type="submit" class="btn btn-success" name="name" value="YES" /></div><div class="col-md-6"><input type="submit" class="btn btn-success" name="name" value="NO" /></div></div>', $sumk->textdomain ),
				'icon' => $sumk->assets( 'images', 'demo-3.png' ),
				'attr' => serialize( array( array(
								'name' => __( 'Unique Pane Id', $sumk->textdomain ),
								'desc' => __( 'Unique name used to identify this pane', $sumk->textdomain ),
								'slug' => 'pane_id',
								'default' => '',
								'type' => 'text' 
							), array(
								'name' => __( 'Next Pane', $sumk->textdomain ),
								'desc' => __( 'Enter the id to the next pane you want to show after you save this pane', $sumk->textdomain ),
								'slug' => 'next_pane',
								'default' => '',
								'type' => 'text' 
							), array(
								'name' => __( 'Previous Pane', $sumk->textdomain ),
								'desc' => __( 'Enter the id to the previous pane you want to show if you click the previous button', $sumk->textdomain ),
								'slug' => 'previous_pane',
								'default' => '',
								'type' => 'text' 
							), array(
								'name' => __( 'Show this question by default', $sumk->textdomain ),
								'desc' => __( 'Choose if this question should be shown by default or not', $sumk->textdomain ),
								'slug' => 'show_by_default',
								'default' => 'no',
								'type' => 'switch' 
							), array(
								'name' => __( 'Validator Function', $sumk->textdomain ),
								'desc' => __( 'Enter the name of the javascript function you want to use for validation.  This function should return true (continue submitting form) or false (do not submit data).', $sumk->textdomain ),
								'slug' => 'validator_function',
								'default' => '',
								'type' => 'text' 
							), array(
								'name' => __( 'Enter question to display', $sumk->textdomain ),
								'desc' => __( 'This is the question that will be displayed in a large font at the top..', $sumk->textdomain ),
								'slug' => 'question',
								'default' => '',
								'type' => 'text' 
							)
						) ),
				'code_type' => 'php_echo',
				'code' => esc_html( '$display = ($show_by_default == \'yes\' ? \'block\' : \'none\');
if (trim($previous_pane) != \'\') {
	$previous_html = \'<div class="previous">&lt; Previous</div>\';
} else {
	$previous_html = \'\';
}
if (trim($validator_function) != \'\') {
	$validator_html = \'
	if (typeof \' . validator_function . \' == "function") { 
			if (!\' . validator_function . \'()) {
				return false;
			}
		}
	\';
} else {
	$validator_html = \'\';
}
$html = <<<EOL
<div id="{$pane_id}" class="text-center" style="display:{$display};">
<h2 class="dark-text">{$question}</h2>
<form action="/save.php" method="POST">
<input type="hidden" name="__submit" value="1" />
<input type="hidden" name="next_pane" value="{$next_pane}" />
<input type="hidden" name="previous_pane" value="{$previous_pane}" />
<div class="flux-answers">{$content}</div>
<i class="please_wait fa fa-spin fa-spinner hidden"></i>
{$previous_html}
</form>
</div>
<script>
//<!--
jQuery(document).ready(function() {
	jQuery("form","#{$pane_id}").on("submit", function() {
		{$validator_html}
		// Show the please wait spinner
		jQuery(".please_wait", "#{$pane_id}").removeClass("hidden");
		jQuery.post("/wp-content/flux.php", jQuery("form","#{$pane_id}").serialize(), function() {
			//LeadiD.formcapture.init();
			// Hide the current div
			jQuery("input,select,textarea", "#{$pane_id}").attr("disabled","disabled");
			jQuery("#{$pane_id}").css("position", "absolute");
			jQuery("#{$pane_id}").hide("slide", {direction: "left"}, 300);
			// Hide the please wait spinner
			jQuery(".please_wait", "#{$pane_id}").addClass("hidden");
			// Show the next div
			jQuery("input,select,textarea", "#" + jQuery("input[name=next_pane]","#{$pane_id}").val()).removeAttr("disabled");
			jQuery("#" + jQuery("input[name=next_pane]","#{$pane_id}").val()).show("slide", {direction: "right" }, 300, function() {
				jQuery("#" + jQuery("input[name=next_pane]","#{$pane_id}").val()).css("position", "relative");
				jQuery("#{$pane_id}").css("position", "relative");
			});
		});
		return false;
	});

	jQuery("div.previous", "#{$pane_id}").click(function() {
		// Hide the current div
		jQuery("input,select,textarea", "#{$pane_id}").attr("disabled", "disabled");
		jQuery("#{$pane_id}").css("position", "absolute");
		jQuery("#{$pane_id}").hide("slide", {direction: "right"}, 300);
		// Show the previous div
		jQuery("input,select,textarea", "#" + jQuery("input[name=previous_pane]","#{$pane_id}").val()).removeAttr("disabled");
		jQuery("#" + jQuery("input[name=previous_pane]","#{$pane_id}").val()).show("slide", {direction: "left" }, 300, function() {
			jQuery("#" + jQuery("input[name=previous_pane]","#{$pane_id}").val()).css("position", "relative");
			jQuery("#{$pane_id}").css("position", "relative");
		});
	});
});
//-->
</script>
EOL;
echo $html;
' )
			) ),
	);

	// Insert new posts
	foreach ( $data as $post ) {
		$post_id = wp_insert_post( $post );
		foreach ( $post['meta'] as $key => $val ) update_post_meta( $post_id, 'sumk_' . $key, $val );
	}
	add_action( 'admin_notices', 'sumk_demo_imported' );
	update_option( $option, true );
}

function sumk_demo_imported() {
	global $sumk;
?>
	<div class="updated">
		<p><strong>
			<?php _e( '3 demo shortcodes added to the database', $sumk->textdomain ); ?>.
			<a href="<?php echo admin_url( 'edit.php?post_type=shortcodesultimate' ); ?>"><?php _e( 'View', $sumk->textdomain ); ?></a>
		</strong></p>
	</div>
	<?php
}
